//===--- MachO_x86_64.h - JIT link functions for MachO/x86-64 ---*- C++ -*-===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//
//
// jit-link functions for MachO/x86-64.
//
//===----------------------------------------------------------------------===//

#ifndef LLVM_EXECUTIONENGINE_JITLINK_MACHO_X86_64_H
#define LLVM_EXECUTIONENGINE_JITLINK_MACHO_X86_64_H

#include "llvm/ExecutionEngine/JITLink/JITLink.h"
#include "llvm/Support/Compiler.h"

namespace llvm {
namespace jitlink {

/// Create a LinkGraph from a MachO/x86-64 relocatable object.
///
/// Note: The graph does not take ownership of the underlying buffer, nor copy
/// its contents. The caller is responsible for ensuring that the object buffer
/// outlives the graph.
LLVM_ABI Expected<std::unique_ptr<LinkGraph>>
createLinkGraphFromMachOObject_x86_64(
    MemoryBufferRef ObjectBuffer, std::shared_ptr<orc::SymbolStringPool> SSP);

/// jit-link the given LinkGraph.
///
/// If PrePrunePasses is empty then a default mark-live pass will be inserted
/// that will mark all exported atoms live. If PrePrunePasses is not empty, the
/// caller is responsible for including a pass to mark atoms as live.
///
/// If PostPrunePasses is empty then a default GOT-and-stubs insertion pass will
/// be inserted. If PostPrunePasses is not empty then the caller is responsible
/// for including a pass to insert GOT and stub edges.
LLVM_ABI void link_MachO_x86_64(std::unique_ptr<LinkGraph> G,
                                std::unique_ptr<JITLinkContext> Ctx);

/// Returns a pass suitable for splitting __eh_frame sections in MachO/x86-64
/// objects.
LLVM_ABI LinkGraphPassFunction createEHFrameSplitterPass_MachO_x86_64();

/// Returns a pass suitable for fixing missing edges in an __eh_frame section
/// in a MachO/x86-64 object.
LLVM_ABI LinkGraphPassFunction createEHFrameEdgeFixerPass_MachO_x86_64();

} // end namespace jitlink
} // end namespace llvm

#endif // LLVM_EXECUTIONENGINE_JITLINK_MACHO_X86_64_H
